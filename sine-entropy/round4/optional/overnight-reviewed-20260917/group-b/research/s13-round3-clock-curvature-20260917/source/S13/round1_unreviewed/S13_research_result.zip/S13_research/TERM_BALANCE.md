# Term balance

All terms below use the actual count law `pi_l`.  No layer derivative is
suppressed.

## A. Reviewed uniform-slice decomposition

For `u_l` uniform, `r_l=q_l/u_l`, and
`F_l=D(q_l||u_l)`,

`H = Phi - sum_l pi_l F_l`,

where `Phi=H(M)+sum_l pi_l log binom(n,l)`.  Therefore

`H'' = Phi'' - sum_l [pi_l F_l'' + 2 pi_l' F_l' + pi_l'' F_l]`.

Writing

`F_l'' = sum q_l'' log(q_l/u_l) + sum (q_l')^2/q_l`,

the first summand is the conditional acceleration/cross-entropy response and
the second is the conditional Fisher term.  The count block is

`Phi'' = H(M)'' + sum_l pi_l'' log binom(n,l)`

with

`H(M)'' = -sum pi_l'' log pi_l - sum (pi_l')^2/pi_l`.

The exact full Fisher split is

`sum_S (p_S')^2/p_S = sum_l (pi_l')^2/pi_l + sum_l pi_l sum_S (q_l')^2/q_l`.

## B. Fourier-reference decomposition for the actual law

Define `nu_(n,l)=n^(-l) exp(U_n)` and
`D_l=D(q_l||nu_(n,l))`, with actual-to-reference orientation.  Then

`H = H(M) + E[M] log n - E[U_n(Y)] - D_F`,

`D_F=sum_l pi_l D_l`.

The exact contributions to the second derivative are:

| block | second derivative | sign information |
|---|---|---|
| count entropy | `H(M)''` | reviewed concave, but no new magnitude bound here |
| expected log partition | `(E[M] log n)''=0` | exact |
| negative potential | `-(E U_n)''=-2n log n` | exact |
| aggregate reference KL | `-D_F''` | no automatic sign |

The aggregate KL derivative is

`D_F''=sum_l[pi_l D_l''+2 pi_l' D_l'+pi_l'' D_l]`,

`D_l'=sum q_l' log(q_l/nu_l)`,

`D_l''=sum q_l'' log(q_l/nu_l)+sum (q_l')^2/q_l`.

Thus the final exact balance is

`H'' = H(M)'' - 2n log n`
`      - sum_l pi_l sum q_l'' log(q_l/nu_l)`
`      - sum_l pi_l sum (q_l')^2/q_l`
`      - 2 sum_l pi_l' D_l'`
`      - sum_l pi_l'' D_l`.

The `n log n` potential term cannot be dropped.  It is paid/cancelled only by
the remaining actual terms, principally the aggregate Fourier-reference KL
curvature.  A KL value estimate alone does not control this display.

On a compact interior `a in [delta,1-c-delta]`, score data processing gives

`I(Y) <= k/[(a+c)(1-a-c)] + (n-k)/[a(1-a)] = O(n)`.

The exact Fisher split then makes the count Fisher plus aggregate conditional
Fisher `O(n)`.  Therefore an `n log n` cancellation cannot come from Fisher;
it must be carried by acceleration/cross-entropy and moving-weight terms (or
remain in the full entropy curvature).

## C. Corrected balance for the mean-overlap surrogate

Let `tilde D_F=sum_l pi_l D(tilde q_l||nu_l)` and

`C_n=E_(tilde p) U_n-E_p U_n`.

Theorem A proves `C_n>0` in the interior for `P_(6,3)` and `P_(8,4)`, but gives
no curvature sign.  The exact surrogate reference balance is

`tilde H'' = H(M)'' - 2n log n - C_n'' - tilde D_F''`.

The complete expansion of `tilde D_F''` again contains
`pi_l tilde D_l''`, `2 pi_l' tilde D_l'`, and `pi_l'' tilde D_l`, with
conditional acceleration and Fisher inside `tilde D_l''`.

In the recovered transport notation, the separately displayed moving-layer
term was

`W_n=sum_l[-2 pi_l' s_l tilde J_l + pi_l'' tilde F_l]`.

This report does not pay `W_n`.  A valid continuation must retain `C_n` and the
full actual/surrogate replacement budget as well as `W_n`; it may not transfer
the actual potential identity to the surrogate by mean-overlap matching.

## D. Orders tracked and not claimed

- Exact leading potential curvature: `-2n log n`.
- Count curvature: retained exactly; no new uniform `O(n)` theorem claimed.
- Conditional/count Fisher: retained exactly.
- Moving weights `pi_l'`, `pi_l''`: retained exactly.
- Surrogate potential mismatch: exact positive value in the two finite cases;
  no growing order or curvature sign claimed.
- No `n` or `n log n` term is discarded in any displayed identity.
