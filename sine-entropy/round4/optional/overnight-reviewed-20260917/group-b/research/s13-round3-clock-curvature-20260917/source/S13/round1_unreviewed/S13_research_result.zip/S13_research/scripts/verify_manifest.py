#!/usr/bin/env python3
"""Verify a simple SHA-256 manifest relative to the package root."""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_manifest.py SHA256SUMS")
    manifest = Path(sys.argv[1]).resolve()
    root = manifest.parent
    failures = []
    count = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, rel = line.split("  ", 1)
        path = root / rel
        count += 1
        if not path.is_file():
            failures.append(f"missing: {rel}")
            continue
        actual = sha256(path)
        if actual != expected:
            failures.append(f"hash mismatch: {rel}")
    if failures:
        print("\n".join(failures))
        raise SystemExit(1)
    print(f"verified {count} files")


if __name__ == "__main__":
    main()
