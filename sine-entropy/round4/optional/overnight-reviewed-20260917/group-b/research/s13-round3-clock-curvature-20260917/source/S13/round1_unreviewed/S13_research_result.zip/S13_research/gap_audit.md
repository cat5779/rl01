# Gap audit

## What is closed in this package

1. The cyclic logarithmic Vandermonde potential and its layer reference law are
   normalized exactly.
2. The actual entropy/reference identity is proved with a fixed KL orientation.
3. The exact source of the `2n log n` curvature is identified.
4. Every count, layer, acceleration and Fisher derivative in that identity is
   displayed.
5. The recovered mean-overlap BL surrogate is specified completely enough for
   the test: law, rates, clock, maximal-overlap initial condition, and domain.
6. The aggregate potential-transfer equality is disproved analytically for
   genuine `P_(6,3)` and `P_(8,4)` for every interior legal parameter.
7. Full-atom checks including `p'`, `p''`, `pi'`, `pi''`, and Fisher are rebuilt
   for both projections at a fixed high-contrast interior point.

## Target-level gaps that remain

- No sign is proved for the full entropy curvature on growing contiguous
  `P_(n,k)` at fixed density and general `37/40<c<1`.
- The route counterexample is finite-dimensional.  It diagnoses an exact
  algebraic transfer failure and is not promoted to a thermodynamic obstruction.
- No growing estimate is proved for the mismatch `C_n`, its second derivative,
  or its integrated Jensen defect.
- The recovered surrogate entropy-value approximation is not independently
  reconstructed.
- The recovered actual/surrogate `O(log n)` KL statement is not reconstructed;
  its orientation was absent from the stalled checkpoint.
- No conversion from any value/KL approximation to the required signed
  moving-layer Jensen budget is supplied.
- The count asymptotic `H(M)''=O(n)` on a declared fixed interior is not proved.
- The recovered `W_n` term remains unpaid.
- The reviewed Fourier-to-Toeplitz value bridge cannot close a curvature or
  Jensen sign until a genuine signed sublinear-loss estimate is available.

## Exact claim refuted and why it mattered

The refuted claim is not the sine target and is not every Fourier transport
method.  It is the exact equality (R) that the explicit mean-overlap surrogate
preserves the actual aggregate cyclic Fourier potential under the same count
weights.  That equality would have allowed the surrogate to inherit the actual
quadratic potential formula and its `2n log n` curvature without an additional
term.  Theorem A shows that this inheritance is false; a corrected approach
must pay `C_n`.

## Independence and evidence limits

The work was self-checked, not independently audited.  SymPy exact arithmetic
certifies the finite polynomial and algebraic identities under the script's
logic.  Decimal entropy residuals are high-precision diagnostics, not interval
proofs.  The analytic theorem does not rely on those decimal residuals.
