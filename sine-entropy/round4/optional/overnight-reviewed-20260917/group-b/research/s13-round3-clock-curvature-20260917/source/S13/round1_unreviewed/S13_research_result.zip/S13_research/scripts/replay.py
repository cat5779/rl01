#!/usr/bin/env python3
"""Replay the S13 exact certificates and diagnostics into a fresh directory."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict


def load_json(path: Path) -> Dict[str, Any]:
    # Universal-newline decoding plus semantic JSON comparison avoids CRLF traps.
    return json.loads(path.read_text(encoding="utf-8"))


def run(cmd: list[str], cwd: Path) -> None:
    completed = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if completed.returncode != 0:
        sys.stderr.write(completed.stdout)
        sys.stderr.write(completed.stderr)
        raise SystemExit(completed.returncode)
    sys.stdout.write(completed.stdout)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    out = args.output_dir.resolve()
    frozen = root / "evidence" / "frozen"
    if out == frozen.resolve():
        raise SystemExit("refusing to overwrite frozen evidence")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    run([sys.executable, str(root / "scripts" / "potential_counterexample.py"), "--output-dir", str(out)], root)
    run([sys.executable, str(root / "scripts" / "full_atom_checks.py"), "--output-dir", str(out)], root)

    fresh_p = load_json(out / "potential_counterexample.json")
    old_p = load_json(frozen / "potential_counterexample.json")
    fresh_f = load_json(out / "full_atom_checks.json")
    old_f = load_json(frozen / "full_atom_checks.json")

    checks = {
        "fresh_potential_all_exact": fresh_p["all_exact_checks_pass"] is True,
        "fresh_full_atom_all_exact": fresh_f["all_exact_checks_pass"] is True,
        "fresh_full_atom_numeric_threshold": fresh_f["all_numeric_checks_pass_1e_minus_80"] is True,
        "polynomial_certificates_semantically_match_frozen": (
            fresh_p["exact_polynomial_certificates"] == old_p["exact_polynomial_certificates"]
        ),
        "reference_partitions_semantically_match_frozen": (
            fresh_p["reference_partition_checks"] == old_p["reference_partition_checks"]
        ),
        "fourier_exact_flags_match_frozen": (
            [
                (
                    x["n"],
                    x["k"],
                    x["cauchy_binet_partition"],
                    x["partition_identity_exact"],
                    x["input_normalization_exact"],
                    x["nonconstant_witness"],
                )
                for x in fresh_p["fourier_input_potential"]
            ]
            == [
                (
                    x["n"],
                    x["k"],
                    x["cauchy_binet_partition"],
                    x["partition_identity_exact"],
                    x["input_normalization_exact"],
                    x["nonconstant_witness"],
                )
                for x in old_p["fourier_input_potential"]
            ]
        ),
        "full_atom_exact_sections_match_frozen": (
            [
                (
                    x["n"],
                    x["k"],
                    x["c_exact"],
                    x["a_exact"],
                    x["global_output_jets_exact"],
                    x["global_count_jets_exact"],
                    x["count_mean_jets_exact"],
                    x["orbit_jet_formulas_all_exact"],
                    x["layer_count_jet_checks"],
                    x["all_exact_algebra_checks_pass"],
                )
                for x in fresh_f["cases"]
            ]
            == [
                (
                    x["n"],
                    x["k"],
                    x["c_exact"],
                    x["a_exact"],
                    x["global_output_jets_exact"],
                    x["global_count_jets_exact"],
                    x["count_mean_jets_exact"],
                    x["orbit_jet_formulas_all_exact"],
                    x["layer_count_jet_checks"],
                    x["all_exact_algebra_checks_pass"],
                )
                for x in old_f["cases"]
            ]
        ),
    }
    passed = all(checks.values())
    summary = {
        "schema": "s13-replay-summary-v1",
        "passed": passed,
        "checks": checks,
        "fresh_max_residuals": [x["max_abs_numeric_residual"] for x in fresh_f["cases"]],
    }
    (out / "replay_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(summary, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
