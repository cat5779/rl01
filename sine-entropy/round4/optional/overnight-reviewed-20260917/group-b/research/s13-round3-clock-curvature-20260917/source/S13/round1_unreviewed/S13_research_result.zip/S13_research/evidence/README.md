# Evidence layout

- `frozen/` contains the outputs cited by `proof.md`.  They are read-only in the
  delivered package.
- `replay/` contains a clean rerun made after freezing.  `replay_summary.json`
  records semantic agreement of the exact sections and the numeric threshold.
- `checkpoints/` contains the measured start and concise mathematical recovery
  checkpoints.

The exact theorem relies on the analytic proof and the integer-polynomial
certificates.  Decimal entropy/KL/Fisher residuals are diagnostics only.
