# Checkpoint 03 — rebuilt full-atom validation

UTC: 2026-09-16T15:38:51.299765+00:00

Independent exact algebraic jets were rebuilt for genuine P_(6,3) and P_(8,4)
at c=19/20, a=1/40.  Two orbit-level formulas for p,p',p'' agree exactly;
layer sums equal independently differentiated count probabilities pi,pi',pi'';
global probability jets are (1,0,0), and count mean jets are (ck+na,n,0).
High-precision evaluation from those exact jets verifies the full entropy/layer
identity, the count/conditional Fisher split, the Fourier-reference value
identity, E[U]''=2n log n, and the reference-curvature identity with residuals
below 1.3e-108.  These transcendental evaluations are diagnostics; exact
algebra and the positive-polynomial route theorem are the certificates.
