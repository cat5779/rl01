# Recovery ledger

| Item | Classification this round | Exact scope / evidence |
|---|---|---|
| Full channel atom formula and count law | reviewed input, independently re-derived | `proof.md` Section 2; exact replay in `full_atom_checks.json` |
| Uniform-slice entropy decomposition `H=Phi-sum pi F` | reviewed input, independently replayed | exact jets plus high-precision identity in `scripts/full_atom_checks.py` |
| Moving-layer derivatives and Fisher split | reviewed input, independently replayed | `proof.md` (3.8)--(3.10), (7.2)--(7.3); exact jets and residuals |
| Mean-overlap BL surrogate law | reconstructed from unreviewed summary | law, generator rates, clock, initial condition, domains in `proof.md` Section 2 |
| Recovered surrogate entropy approximation `O(sqrt(n) log n)` | **still unreviewed / unused** | no recovered proof or package; not assumed |
| Recovered all-mode acceleration payment | **still unreviewed / unused** | not needed for the route counterexample |
| Recovered actual/surrogate KL `O(log n)` | **still missing / unused** | orientation and uniformity not supplied |
| Fourier potential definition | reconstructed and proved | `U_n` in (3.1) |
| Fourier reference partition | reconstructed and proved | `sum exp U=n^l`, Lemma 3.1; exact `n=6,8` checks |
| Actual Fourier-reference entropy identity | reconstructed and proved | (1.1), Lemma 3.2 |
| Actual aggregate potential formula | reconstructed and proved | (3.6), including all actual count weights implicitly |
| Claimed `-2n log n` curvature | corrected and proved at exact finite `n` | potential contributes exactly `-2n log n`; partition term has zero curvature; full block is `H(M)''-2n log n` |
| Growing remainder `H(M)''=O(n)` | **still missing** | no derivative-uniform local-limit proof supplied here |
| Transfer of potential cancellation to mean-overlap surrogate | **refuted** | Theorem A: strict aggregate mismatch for genuine `P_(6,3)` and `P_(8,4)`, all legal interior parameters |
| Six/eight-site full-atom checks from stalled lead | rebuilt independently | exact `p,p',p''`, `pi,pi',pi''`; Fisher and reference identities; scripts/evidence included |
| Payment of recovered `W_n` | **still missing** | not implied by the new mismatch theorem |
| Sine entropy-rate target | **open** | no target-level claim made |
