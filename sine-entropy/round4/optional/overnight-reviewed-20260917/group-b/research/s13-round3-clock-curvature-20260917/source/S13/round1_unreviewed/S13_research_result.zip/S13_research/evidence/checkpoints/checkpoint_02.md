# Checkpoint 02 — new exact route counterexample

UTC: 2026-09-16T15:38:50.637406+00:00

For the recovered mean-overlap Bernoulli--Laplace surrogate on the genuine
half-density Fourier inputs P_(6,3) and P_(8,4), every nontrivial count slice
has surrogate degree-two multiplier strictly larger than the actual channel
multiplier for every s=a(1-c-a)/c>0.  Exact positive-coefficient polynomial
certificates cover l=2,3,4 for n=6 and l=2,...,6 for n=8 by complement symmetry.
The Fourier potential centered on a slice is a nonconstant degree-two Johnson
harmonic, and its Fourier Gibbs input mean exceeds its uniform mean.  Therefore

E_tilde[U_n(Y)] > E_actual[U_n(Y)]

for every 0<c<1 and 0<a<1-c in both genuine P_(6,3), P_(8,4) cases.  This is an
analytic aggregate counterexample to transferring the actual Fourier-potential
cancellation to the mean-overlap surrogate.  It is not a target counterexample
and does not rule out a corrected surrogate retaining this mismatch term.
