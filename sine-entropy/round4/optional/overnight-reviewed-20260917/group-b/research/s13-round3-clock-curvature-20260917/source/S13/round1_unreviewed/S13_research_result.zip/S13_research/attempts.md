# Attempts and preserved failures

## Attempt 1 — identify a normalized Fourier reference

**Question.**  Is the reported Fourier potential a genuine layerwise reference,
with orbit multiplicities and normalization fixed exactly?

**Result.**  Yes.  The logarithmic squared Vandermonde potential has partition
`n^l` by Cauchy--Binet.  This gives a genuine probability `nu_(n,l)` and fixes
the KL orientation as `D(q_l||nu_(n,l))`.  The resulting entropy identity and
all derivatives are proved in `proof.md`.

## Attempt 2 — attribute `-2 n log n` to the partition normalization

**Initial lead.**  The stalled checkpoint called a
"reference-normalization correction" of curvature `-2 n log n+O(n)`.

**Failure/correction.**  The expected log partition is `E[M] log n`, and
`E[M]=na+ck`, so its second derivative is exactly zero.  The large term comes
from `-E[U_n(Y)]`, whose second derivative is exactly `-2 n log n`.  The full
reference block has curvature `H(M)''-2 n log n`.  Calling the partition term
itself the source of that curvature is incorrect.

**Unpaid subclaim.**  The additional growing assertion `H(M)''=O(n)` on a fixed
interior was not independently proved here.  It is not needed for the route
counterexample and remains listed as a gap.

## Attempt 3 — transfer the actual potential cancellation to the mean-overlap surrogate

**Frozen route statement.**  With the same actual count weights, test

`sum_l pi_l E_(tilde q_l) U_n = sum_l pi_l E_(q_l) U_n`.

**Result.**  Refuted analytically.  On half-density slices, the potential is a
pure degree-two Johnson observable.  The mean-overlap clock fixes degree one,
so BL assigns multiplier `lambda_1^(2(n-1)/n)`.  Exact binomial formulas give
the actual degree-two multiplier.  For all nontrivial layers of `P_(6,3)` and
`P_(8,4)`, exact positive-coefficient polynomials prove the surrogate multiplier
is strictly larger.  Every count weight is positive, and the Fourier Gibbs
input has a strictly positive potential excess, so the aggregate inequality is
strict throughout `0<a<1-c`, `0<c<1`.

## Attempt 4 — infer a curvature sign from the positive mismatch value

**Temptation.**  Since
`C_n(a)=E_tilde U_n-E_actual U_n>0` in the interior and vanishes at the channel
endpoints, use its sign to pay the surrogate Hessian.

**Rejected.**  A positive function can have either second-derivative sign and
can have a Jensen defect of either sign on a subchord.  The corrected surrogate
identity contains `-C_n''`; it must be retained or integrated exactly.  No sign
for it is claimed.

## Attempt 5 — use the recovered `O(log n)` KL lead

**Rejected as an input.**  The stalled checkpoint did not specify the KL
direction, constants, domain, or a proof.  Even a correct KL value estimate
would not by itself control entropy curvature, cross-entropy response, or the
full moving-layer Jensen budget.  No such claim is used in the proof.

## Attempt 6 — generalize the exact multiplier inequality to all half-density sizes

Exploratory symbolic calculations suggested similar positive polynomials for
additional small `k`, but no uniform proof was completed.  These calculations
are deliberately not included as evidence and no growing-family theorem is
claimed.  The certified result is exactly `k=3,4` with all their nontrivial
layers.
