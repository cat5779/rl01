# Source ledger

## Frozen public packet revision

Repository: `cat5779/rl01`

Commit: `191297f3073e60f5954a93ae5e6e94c32447b590`

All packet files below were read at that exact commit.  No repository write and
no pull request was made.

- Assignment:
  `sine-entropy/round4/next/S13.md`
- Contract:
  `sine-entropy/round4/next/CONTRACT.md`
- Frozen target:
  `sine-entropy/round4/TARGET.md`
- Reviewed inputs:
  `sine-entropy/round4/KNOWN_RESULTS.md`
- Pitfalls:
  `sine-entropy/round4/PITFALLS.md`
- Unreviewed stalled checkpoint:
  `sine-entropy/round4/next/S5_STALLED_CHECKPOINT.md`
- Unreviewed recovered round-three author summary:
  `sine-entropy/round4/next/S5_ROUND3_AUTHOR_SUMMARY.md`
- Reviewed earlier S5 proof:
  `sine-entropy/round4/optional/S5/proof.md`
- Reading map:
  `sine-entropy/round4/READING_MAP.md`

Raw base URL:

`https://raw.githubusercontent.com/cat5779/rl01/191297f3073e60f5954a93ae5e6e94c32447b590/`

## Imported statements and treatment

- From the frozen target: the exact homogeneous channel formula, the projection
  input atom formula, and the complete full-atom entropy Hessian.  They are
  restated and independently replayed here.
- From reviewed inputs / earlier S5: the count-layer disintegration, normalized
  BL rates, and the warning that no common clock exists for growing Fourier
  families.  The theorem in this package does not rely on the old no-clock
  conclusion; it derives the target-specific potential multipliers directly.
- From the recovered S5 summary: only the explicit definition of the
  mean-overlap surrogate was used as a lead.  Its approximation, acceleration,
  KL, and `W_n` claims were not accepted as premises.

## External literature

No non-elementary external theorem is used in the new proof.  Cauchy--Binet,
the Vandermonde determinant, differentiation of `x^n-1`, and finite Markov
chain calculations are proved or applied explicitly.  Candidate C3 considered
local-limit/saddlepoint tools but was not promoted, so no literature theorem
from it is imported.
