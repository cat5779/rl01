# Candidate ledger

The assignment allowed at most three structurally different mechanisms and at
most two promotions.  Recovered S5 claims were treated only as leads.

## C1 — Fourier Gibbs reference / root-discriminant thermodynamic integration

- **Field/mechanism:** finite determinantal algebra and finite Gibbs families.
- **Frozen statement before promotion:** define
  `U_n(S)=sum_{i<j in S} log|z_i-z_j|^2` and
  `nu_(n,l)=n^(-l) exp(U_n)`.  Prove its partition function exactly, derive the
  actual entropy decomposition with a declared KL orientation, and calculate
  the complete `a`-curvature of its potential expectation.
- **Fast test:** Cauchy--Binet for the first `l` Fourier columns and the
  derivative of `x^n-1` at an `n`th root of unity.
- **Decision:** **promoted**.
- **Outcome:** succeeded.  The exact identities are (1.1), (3.3), (3.6), and
  (3.7) in `proof.md`.  The partition term `E[M] log n` has zero curvature;
  the `-2n log n` term comes from the potential in the combined reference
  block.  The aggregate reference KL retains all moving-layer and Fisher terms.

## C2 — Johnson-scheme spectral test of mean-overlap potential transfer

- **Field/mechanism:** algebraic combinatorics / reversible finite Markov chains.
- **Frozen statement before promotion:** for the explicit mean-overlap BL
  surrogate, test the exact aggregate equality
  `sum pi_l E_tilde[U_n]=sum pi_l E_actual[U_n]` on genuine coupled
  `P_(6,3)` and `P_(8,4)`, using the actual count weights.  A counterexample
  must be analytic or exact, not a floating scan.
- **Fast falsification test:** show the centered cyclic potential is pure
  Johnson degree two; compare the actual degree-two multiplier with the BL heat
  multiplier forced by degree-one mean matching on every nontrivial layer.
- **Decision:** **promoted**.
- **Outcome:** the equality is false throughout the entire legal interior for
  both projections.  Positive-coefficient polynomial identities certify every
  layer, and the weighted aggregate gap is strictly positive.  This is Theorem
  A in `proof.md` and is the new route-level result of this round.

## C3 — local-limit / saddlepoint control of count entropy and recovered KL

- **Field/mechanism:** probability and analytic combinatorics (adjacent field).
- **Frozen scouting question:** can a uniform differentiable local limit theorem
  on a fixed interior immediately prove `H(M)''=O(n)` and convert a stated
  `O(log n)` actual/surrogate KL value bound into the required signed Jensen
  budget?
- **Fast rejection test:** list the derivatives actually needed.  The count
  estimate requires uniform control after two parameter derivatives, while a
  KL value bound alone gives neither entropy curvature nor cross-entropy
  response.  The recovered S5 lead did not state the KL orientation or such
  derivative bounds.
- **Decision:** not promoted.
- **Reason:** pursuing a generic local limit theorem would not pay the complete
  moving-layer combination and was unnecessary once C2 produced an exact new
  counterexample.  No external theorem from this candidate is used.

Promoted candidates: 2.  Total candidates scouted: 3.
