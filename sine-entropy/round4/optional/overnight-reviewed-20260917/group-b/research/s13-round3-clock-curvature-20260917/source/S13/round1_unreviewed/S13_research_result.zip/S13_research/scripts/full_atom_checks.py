#!/usr/bin/env python3
"""Rebuild exact full-atom jets and high-precision entropy identities for S13.

Exact arithmetic is used for the Fourier input atoms, channel p,p',p'', count
weights pi,pi',pi'', and all layer-sum identities.  Transcendental entropy
identities are then evaluated at high precision from those exact jets.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import sympy as sp


@lru_cache(maxsize=None)
def dist2(n: int, d: int) -> sp.Expr:
    return sp.simplify(2 - 2 * sp.cos(2 * sp.pi * sp.Rational(d % n, n)))


def vandermonde_sq(n: int, subset: Sequence[int]) -> sp.Expr:
    ans = sp.Integer(1)
    for i, j in itertools.combinations(subset, 2):
        ans *= dist2(n, j - i)
    return sp.simplify(ans)


def subsets(n: int, l: int | None = None) -> Iterable[Tuple[int, ...]]:
    if l is None:
        for r in range(n + 1):
            yield from itertools.combinations(range(n), r)
    else:
        yield from itertools.combinations(range(n), l)


def mul_jets(x: Tuple[sp.Expr, sp.Expr, sp.Expr], y: Tuple[sp.Expr, sp.Expr, sp.Expr]) -> Tuple[sp.Expr, sp.Expr, sp.Expr]:
    x0, x1, x2 = x
    y0, y1, y2 = y
    return (
        sp.expand(x0 * y0),
        sp.expand(x1 * y0 + x0 * y1),
        sp.expand(x2 * y0 + 2 * x1 * y1 + x0 * y2),
    )


def product_jets(factors: Sequence[Tuple[sp.Expr, sp.Expr, sp.Expr]]) -> Tuple[sp.Expr, sp.Expr, sp.Expr]:
    out = (sp.Integer(1), sp.Integer(0), sp.Integer(0))
    for factor in factors:
        out = mul_jets(out, factor)
    return tuple(sp.factor(x) for x in out)  # type: ignore[return-value]


def channel_factor_jets_bitwise(n: int, k: int, l: int, t: int, a: sp.Rational, c: sp.Rational) -> Tuple[sp.Expr, sp.Expr, sp.Expr]:
    counts = [
        (t, (a + c, sp.Integer(1), sp.Integer(0))),
        (k - t, (1 - a - c, sp.Integer(-1), sp.Integer(0))),
        (l - t, (a, sp.Integer(1), sp.Integer(0))),
        (n - k - l + t, (1 - a, sp.Integer(-1), sp.Integer(0))),
    ]
    factors: List[Tuple[sp.Expr, sp.Expr, sp.Expr]] = []
    for count, factor in counts:
        if count < 0:
            raise ValueError("infeasible intersection")
        factors.extend([factor] * count)
    return product_jets(factors)


def channel_factor_jets_logderivative(n: int, k: int, l: int, t: int, a: sp.Rational, c: sp.Rational) -> Tuple[sp.Expr, sp.Expr, sp.Expr]:
    f = (a + c) ** t * (1 - a - c) ** (k - t) * a ** (l - t) * (1 - a) ** (n - k - l + t)
    g = sp.Integer(0)
    gp = sp.Integer(0)
    entries = [
        (t, a + c, 1),
        (k - t, 1 - a - c, -1),
        (l - t, a, 1),
        (n - k - l + t, 1 - a, -1),
    ]
    for count, value, slope in entries:
        if count:
            g += count * sp.Rational(slope, 1) / value
            gp -= count / value**2  # slope^2=1 for every factor
    return tuple(sp.factor(x) for x in (f, f * g, f * (g**2 + gp)))  # type: ignore[return-value]


def count_jets_symbolic(n: int, k: int, l: int, a0: sp.Rational, c: sp.Rational) -> Tuple[sp.Expr, sp.Expr, sp.Expr]:
    x = sp.symbols("x")
    expr = sp.Integer(0)
    for j in range(max(0, l - (n - k)), min(k, l) + 1):
        expr += (
            sp.binomial(k, j)
            * (x + c) ** j
            * (1 - x - c) ** (k - j)
            * sp.binomial(n - k, l - j)
            * x ** (l - j)
            * (1 - x) ** ((n - k) - (l - j))
        )
    return tuple(sp.factor(sp.diff(expr, x, d).subs(x, a0)) for d in range(3))  # type: ignore[return-value]


def to_mp(x: sp.Expr, dps: int = 120) -> mp.mpf:
    return mp.mpf(str(sp.N(x, dps)))


def quotient_jets(p: Tuple[mp.mpf, mp.mpf, mp.mpf], pi: Tuple[mp.mpf, mp.mpf, mp.mpf]) -> Tuple[mp.mpf, mp.mpf, mp.mpf]:
    p0, p1, p2 = p
    z0, z1, z2 = pi
    q0 = p0 / z0
    q1 = p1 / z0 - p0 * z1 / z0**2
    q2 = p2 / z0 - 2 * p1 * z1 / z0**2 + p0 * (2 * z1**2 / z0**3 - z2 / z0**2)
    return q0, q1, q2


def mpstr(x: mp.mpf, digits: int = 75) -> str:
    return mp.nstr(x, digits)


def build_case(n: int, k: int, c: sp.Rational, a: sp.Rational) -> Dict[str, object]:
    mp.mp.dps = 110

    input_atoms: Dict[Tuple[int, ...], sp.Expr] = {
        A: sp.simplify(vandermonde_sq(n, A) / n**k) for A in subsets(n, k)
    }
    input_sum = sp.simplify(sum(input_atoms.values()))

    # Verify two independent exact jet formulas for every feasible orbit (l,t).
    orbit_jet_checks = []
    orbit_jets: Dict[Tuple[int, int], Tuple[sp.Expr, sp.Expr, sp.Expr]] = {}
    for l in range(n + 1):
        for t in range(max(0, l - (n - k)), min(k, l) + 1):
            j_bit = channel_factor_jets_bitwise(n, k, l, t, a, c)
            j_log = channel_factor_jets_logderivative(n, k, l, t, a, c)
            equal = all(sp.simplify(x - y) == 0 for x, y in zip(j_bit, j_log))
            orbit_jet_checks.append({"l": l, "t": t, "exact_equal": bool(equal)})
            if not equal:
                raise AssertionError(f"orbit jet mismatch at l={l}, t={t}")
            orbit_jets[(l, t)] = j_bit

    output_exact: Dict[Tuple[int, ...], Tuple[sp.Expr, sp.Expr, sp.Expr]] = {}
    for Sset in subsets(n):
        S = set(Sset)
        l = len(Sset)
        sums = [sp.Integer(0), sp.Integer(0), sp.Integer(0)]
        for A, mu in input_atoms.items():
            t = len(S.intersection(A))
            jet = orbit_jets[(l, t)]
            for d in range(3):
                sums[d] += mu * jet[d]
        output_exact[Sset] = tuple(sp.simplify(x) for x in sums)  # type: ignore[assignment]

    count_exact = {l: count_jets_symbolic(n, k, l, a, c) for l in range(n + 1)}
    layer_checks = []
    for l in range(n + 1):
        layer_sums = tuple(sp.simplify(sum(output_exact[S][d] for S in subsets(n, l))) for d in range(3))
        expected = count_exact[l]
        layer_checks.append(
            {
                "l": l,
                "p_sum": [str(x) for x in layer_sums],
                "count_jets": [str(x) for x in expected],
                "exact_equal": [bool(sp.simplify(x - y) == 0) for x, y in zip(layer_sums, expected)],
            }
        )

    global_jets = [sp.simplify(sum(v[d] for v in output_exact.values())) for d in range(3)]
    count_global = [sp.simplify(sum(count_exact[l][d] for l in range(n + 1))) for d in range(3)]
    count_mean = [
        sp.simplify(sum(l * count_exact[l][d] for l in range(n + 1))) for d in range(3)
    ]

    # High-precision evaluation from exact atoms and exact count jets.
    pmp = {S: tuple(to_mp(x) for x in jet) for S, jet in output_exact.items()}
    pimp = {l: tuple(to_mp(x) for x in jet) for l, jet in count_exact.items()}

    H = -mp.fsum(p0 * mp.log(p0) for p0, _, _ in pmp.values())
    H2 = -mp.fsum(p2 * mp.log(p0) + p1**2 / p0 for p0, p1, p2 in pmp.values())
    fisher_full = mp.fsum(p1**2 / p0 for p0, p1, _ in pmp.values())
    acceleration_full = -mp.fsum(p2 * mp.log(p0) for p0, _, p2 in pmp.values())

    HM = -mp.fsum(pi0 * mp.log(pi0) for pi0, _, _ in pimp.values())
    HM2 = -mp.fsum(pi2 * mp.log(pi0) + pi1**2 / pi0 for pi0, pi1, pi2 in pimp.values())
    fisher_count = mp.fsum(pi1**2 / pi0 for pi0, pi1, _ in pimp.values())

    layer_data = []
    layer_term_sum = mp.mpf("0")
    fisher_conditional = mp.mpf("0")
    Dref = mp.mpf("0")
    for l in range(n + 1):
        N = math.comb(n, l)
        pi = pimp[l]
        F = mp.mpf("0")
        F1 = mp.mpf("0")
        F2_acc = mp.mpf("0")
        F2_fisher = mp.mpf("0")
        D = mp.mpf("0")
        for Sset in subsets(n, l):
            q0, q1, q2 = quotient_jets(pmp[Sset], pi)
            logru = mp.log(q0 * N)
            F += q0 * logru
            F1 += q1 * logru
            F2_acc += q2 * logru
            F2_fisher += q1**2 / q0

            V = vandermonde_sq(n, Sset)
            nu = to_mp(V / n**l)
            D += q0 * mp.log(q0 / nu)
        F2 = F2_acc + F2_fisher
        fisher_conditional += pi[0] * F2_fisher
        layer_term = pi[0] * F2 + 2 * pi[1] * F1 + pi[2] * F
        layer_term_sum += layer_term
        Dref += pi[0] * D
        layer_data.append(
            {
                "l": l,
                "pi": [mpstr(x, 55) for x in pi],
                "F_uniform": mpstr(F, 55),
                "F_prime": mpstr(F1, 55),
                "F_second_acceleration": mpstr(F2_acc, 55),
                "F_second_fisher": mpstr(F2_fisher, 55),
                "F_second": mpstr(F2, 55),
                "weighted_second_term": mpstr(layer_term, 55),
                "D_fourier_reference": mpstr(D, 55),
            }
        )

    Phi2 = HM2 + mp.fsum(pimp[l][2] * mp.log(math.comb(n, l)) for l in range(n + 1))
    layer_identity_residual = H2 - (Phi2 - layer_term_sum)
    fisher_decomposition_residual = fisher_full - (fisher_count + fisher_conditional)

    # Fourier-reference decomposition and its second derivative.
    EU = mp.mpf("0")
    EU2 = mp.mpf("0")
    Dref_direct = mp.mpf("0")
    Dref2 = mp.mpf("0")
    for Sset, (p0, p1, p2) in pmp.items():
        l = len(Sset)
        pi0, pi1, pi2 = pimp[l]
        V = vandermonde_sq(n, Sset)
        U = mp.log(to_mp(V))
        lognu = U - l * mp.log(n)
        EU += p0 * U
        EU2 += p2 * U
        Dref_direct += p0 * mp.log(p0 / (pi0 * mp.e**lognu))
        Dref2 += p2 * (mp.log(p0) + 1) + p1**2 / p0 - p2 * lognu
    # subtract the count contribution in D = sum p log p - sum pi log pi - sum p log nu
    Dref2 -= mp.fsum(pi2 * (mp.log(pi0) + 1) + pi1**2 / pi0 for pi0, pi1, pi2 in pimp.values())

    EM = mp.fsum(l * pimp[l][0] for l in range(n + 1))
    reference_value_residual = H - (HM + EM * mp.log(n) - EU - Dref)
    reference_D_two_ways_residual = Dref - Dref_direct
    potential_curvature_residual = EU2 - 2 * n * mp.log(n)
    reference_curvature_residual = H2 - (HM2 - 2 * n * mp.log(n) - Dref2)

    exact_pass = bool(
        input_sum == 1
        and all(all(row["exact_equal"]) for row in layer_checks)
        and global_jets == [1, 0, 0]
        and count_global == [1, 0, 0]
        and count_mean == [n * a + c * k, n, 0]
        and all(row["exact_equal"] for row in orbit_jet_checks)
    )

    residuals = {
        "full_layer_H_second": mpstr(layer_identity_residual),
        "full_fisher_decomposition": mpstr(fisher_decomposition_residual),
        "fourier_reference_value": mpstr(reference_value_residual),
        "fourier_reference_D_two_ways": mpstr(reference_D_two_ways_residual),
        "potential_second_minus_2nlogn": mpstr(potential_curvature_residual),
        "fourier_reference_curvature": mpstr(reference_curvature_residual),
    }
    max_residual = max(abs(mp.mpf(x)) for x in residuals.values())

    return {
        "n": n,
        "k": k,
        "c_exact": str(c),
        "a_exact": str(a),
        "input_atom_count": len(input_atoms),
        "output_atom_count": len(output_exact),
        "input_normalization_exact": str(input_sum),
        "global_output_jets_exact": [str(x) for x in global_jets],
        "global_count_jets_exact": [str(x) for x in count_global],
        "count_mean_jets_exact": [str(x) for x in count_mean],
        "orbit_jet_formulas_all_exact": all(row["exact_equal"] for row in orbit_jet_checks),
        "layer_count_jet_checks": layer_checks,
        "all_exact_algebra_checks_pass": exact_pass,
        "entropy_diagnostics": {
            "H": mpstr(H),
            "H_second": mpstr(H2),
            "H_second_acceleration_term": mpstr(acceleration_full),
            "H_second_negative_fisher_term_magnitude": mpstr(fisher_full),
            "H_count": mpstr(HM),
            "H_count_second": mpstr(HM2),
            "Phi_second": mpstr(Phi2),
            "layer_second_sum": mpstr(layer_term_sum),
            "D_fourier_reference": mpstr(Dref),
            "D_fourier_reference_second": mpstr(Dref2),
            "E_potential": mpstr(EU),
            "E_potential_second": mpstr(EU2),
        },
        "layer_data": layer_data,
        "numeric_residuals": residuals,
        "max_abs_numeric_residual": mpstr(max_residual),
        "numeric_checks_pass_1e_minus_80": bool(max_residual < mp.mpf("1e-80")),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    cases = [
        (6, 3, sp.Rational(19, 20), sp.Rational(1, 40)),
        (8, 4, sp.Rational(19, 20), sp.Rational(1, 40)),
    ]
    results = [build_case(*case) for case in cases]
    result = {
        "schema": "s13-full-atom-check-v1",
        "cases": results,
        "all_exact_checks_pass": all(x["all_exact_algebra_checks_pass"] for x in results),
        "all_numeric_checks_pass_1e_minus_80": all(x["numeric_checks_pass_1e_minus_80"] for x in results),
        "versions": {"sympy": sp.__version__, "mpmath": mp.__version__},
    }
    out = args.output_dir / "full_atom_checks.json"
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(
        json.dumps(
            {
                "output": str(out),
                "all_exact_checks_pass": result["all_exact_checks_pass"],
                "all_numeric_checks_pass_1e_minus_80": result["all_numeric_checks_pass_1e_minus_80"],
                "max_residuals": [x["max_abs_numeric_residual"] for x in results],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
