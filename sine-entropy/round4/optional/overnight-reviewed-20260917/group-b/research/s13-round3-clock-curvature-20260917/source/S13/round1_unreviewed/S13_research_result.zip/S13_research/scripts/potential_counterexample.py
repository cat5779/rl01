#!/usr/bin/env python3
"""Exact certificates for the S13 Fourier-potential/mean-overlap route.

The exact part uses SymPy integer/algebraic arithmetic.  Floating values are
reported only as diagnostics and are never used to certify strict signs.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import sympy as sp

S = sp.symbols("s", positive=True)
X = sp.symbols("x", positive=True)
ZVAR = 1 + 1 / S


def feasible_sum(k: int, l: int, offset: int) -> sp.Expr:
    """Johnson kernel auxiliary polynomial after selecting ``offset`` labels.

    There are k-offset input and k-offset non-input labels left, and l-offset
    output labels still to select.
    """
    kk = k - offset
    ll = l - offset
    lo = max(0, ll - kk)
    hi = min(kk, ll)
    if lo > hi:
        return sp.Integer(0)
    return sp.expand(
        sum(sp.binomial(kk, j) * sp.binomial(kk, ll - j) * ZVAR**j for j in range(lo, hi + 1))
    )


def layer_multipliers(k: int, l: int) -> Tuple[sp.Expr, sp.Expr]:
    """Return exact degree-one and degree-two multipliers relative to max maps."""
    n = 2 * k
    r = min(l, n - l)
    if not (2 <= l <= n - 2):
        raise ValueError("degree-two nontrivial layers satisfy 2 <= l <= n-2")
    z0 = feasible_sum(k, l, 0)
    z1 = feasible_sum(k, l, 1)
    z2 = feasible_sum(k, l, 2)
    beta = sp.Rational(r, k)
    alpha = sp.Rational(r * (r - 1), k * (k - 1))
    lam1 = sp.factor(sp.cancel((ZVAR - 1) * z1 / (beta * z0)))
    theta2 = sp.factor(sp.cancel((ZVAR - 1) ** 2 * z2 / (alpha * z0)))
    return lam1, theta2


def nonnegative_coefficients(poly: sp.Expr) -> bool:
    p = sp.Poly(sp.expand(poly), S)
    return all(c >= 0 for c in p.all_coeffs()) and any(c > 0 for c in p.all_coeffs())


def positive_for_positive_s(expr: sp.Expr) -> Dict[str, object]:
    """Certificate that expr > 0 for s>0 via positive-coefficient numerator."""
    num, den = map(sp.factor, sp.together(expr).as_numer_denom())
    num_poly = sp.Poly(sp.expand(num), S)
    den_poly = sp.Poly(sp.expand(den), S)
    cert = {
        "numerator_factorized": str(num),
        "denominator_factorized": str(den),
        "numerator_coefficients_descending": [int(c) for c in num_poly.all_coeffs()],
        "denominator_coefficients_descending": [int(c) for c in den_poly.all_coeffs()],
        "numerator_nonnegative_coefficients": nonnegative_coefficients(num),
        "denominator_positive_coefficients": all(c > 0 for c in den_poly.all_coeffs()),
        "numerator_vanishes_at_zero": bool(sp.simplify(num.subs(S, 0)) == 0),
        "identity_reconstructed": bool(sp.simplify(expr - num / den) == 0),
    }
    cert["strict_for_s_positive"] = bool(
        cert["numerator_nonnegative_coefficients"]
        and cert["denominator_positive_coefficients"]
        and num_poly.as_expr() != 0
    )
    return cert


def dist2(n: int, d: int) -> sp.Expr:
    return sp.simplify(2 - 2 * sp.cos(2 * sp.pi * sp.Rational(d % n, n)))


def vandermonde_sq(n: int, subset: Sequence[int]) -> sp.Expr:
    out = sp.Integer(1)
    for i, j in itertools.combinations(subset, 2):
        out *= dist2(n, j - i)
    return sp.simplify(out)


def all_subsets(n: int, l: int) -> Iterable[Tuple[int, ...]]:
    return itertools.combinations(range(n), l)


def mp_from_sympy(x: sp.Expr, dps: int = 100) -> mp.mpf:
    return mp.mpf(str(sp.N(x, dps)))


def fourier_potential_data(n: int, k: int) -> Dict[str, object]:
    values: List[Tuple[Tuple[int, ...], sp.Expr]] = [
        (A, vandermonde_sq(n, A)) for A in all_subsets(n, k)
    ]
    partition = sp.simplify(sum(v for _, v in values))
    weights = [(A, sp.simplify(v / n**k)) for A, v in values]
    normalization = sp.simplify(sum(w for _, w in weights))

    mp.mp.dps = 100
    uniform_mean = mp.fsum(mp.log(mp_from_sympy(v)) for _, v in values) / len(values)
    gibbs_mean = mp.fsum(mp_from_sympy(w) * mp.log(mp_from_sympy(v)) for (A, w), (_, v) in zip(weights, values))
    delta = gibbs_mean - uniform_mean

    if (n, k) == (6, 3):
        A_hi, A_lo = (0, 2, 4), (0, 1, 2)
    elif (n, k) == (8, 4):
        A_hi, A_lo = (0, 2, 4, 6), (0, 1, 2, 3)
    else:
        A_hi = tuple(range(0, 2 * k, 2))[:k]
        A_lo = tuple(range(k))

    return {
        "n": n,
        "k": k,
        "cauchy_binet_partition": str(partition),
        "expected_partition": str(n**k),
        "partition_identity_exact": bool(sp.simplify(partition - n**k) == 0),
        "input_normalization_exact": bool(normalization == 1),
        "nonconstant_witness": {
            "subset_high": list(A_hi),
            "vandermonde_sq_high": str(vandermonde_sq(n, A_hi)),
            "subset_low": list(A_lo),
            "vandermonde_sq_low": str(vandermonde_sq(n, A_lo)),
            "different_exact": bool(sp.simplify(vandermonde_sq(n, A_hi) - vandermonde_sq(n, A_lo)) != 0),
        },
        "delta_U_gibbs_minus_uniform_decimal": mp.nstr(delta, 80),
        "delta_U_positive_floating_diagnostic": bool(delta > 0),
    }


def count_probability(n: int, k: int, c: sp.Rational, a: sp.Rational, l: int) -> sp.Expr:
    out = sp.Integer(0)
    for j in range(max(0, l - (n - k)), min(k, l) + 1):
        out += (
            sp.binomial(k, j)
            * (a + c) ** j
            * (1 - a - c) ** (k - j)
            * sp.binomial(n - k, l - j)
            * a ** (l - j)
            * (1 - a) ** ((n - k) - (l - j))
        )
    return sp.factor(out)


def aggregate_diagnostic(n: int, k: int, c: sp.Rational, a: sp.Rational, delta_u: mp.mpf) -> Dict[str, object]:
    mp.mp.dps = 100
    sval = sp.factor(a * (1 - c - a) / c)
    exponent = sp.Rational(2 * (n - 1), n)
    layer_rows = []
    coefficient = mp.mpf("0")
    pi_sum = sp.Integer(0)
    for l in range(n + 1):
        pi_l = count_probability(n, k, c, a, l)
        pi_sum += pi_l
        r = min(l, n - l)
        if 2 <= l <= n - 2:
            alpha = sp.Rational(r * (r - 1), k * (k - 1))
            lam1, theta2 = layer_multipliers(k, l)
            lamv = mp_from_sympy(lam1.subs(S, sval))
            thetav = mp_from_sympy(theta2.subs(S, sval))
            diff = lamv ** mp.mpf(str(sp.N(exponent, 80))) - thetav
            term = mp_from_sympy(pi_l * alpha) * diff
            coefficient += term
            layer_rows.append(
                {
                    "l": l,
                    "pi_exact": str(pi_l),
                    "alpha_exact": str(alpha),
                    "lambda1_decimal": mp.nstr(lamv, 50),
                    "theta2_decimal": mp.nstr(thetav, 50),
                    "surrogate_minus_actual_multiplier_decimal": mp.nstr(diff, 50),
                    "weighted_coefficient_decimal": mp.nstr(term, 50),
                }
            )
    return {
        "c_exact": str(c),
        "a_exact": str(a),
        "s_exact": str(sval),
        "pi_sum_exact": str(sp.simplify(pi_sum)),
        "aggregate_multiplier_coefficient_decimal": mp.nstr(coefficient, 70),
        "aggregate_potential_gap_decimal": mp.nstr(coefficient * delta_u, 70),
        "layers": layer_rows,
    }



def direct_enumeration_check(k: int, l: int) -> Dict[str, object]:
    """Independent exact enumeration of the h1/h2 kernel and BL eigenvalues."""
    n = 2 * k
    A = set(range(k))
    i, r, j, t = 0, 1, k, k + 1

    def h1(state: set[int]) -> int:
        return int(i in state) - int(j in state)

    def h2(state: set[int]) -> int:
        return (int(i in state) - int(j in state)) * (int(r in state) - int(t in state))

    states = [set(q) for q in itertools.combinations(range(n), l)]
    kernel_h1 = sp.expand(sum(X ** len(A.intersection(q)) * h1(q) for q in states))
    kernel_h2 = sp.expand(sum(X ** len(A.intersection(q)) * h2(q) for q in states))

    def aux(offset: int) -> sp.Expr:
        kk = k - offset
        ll = l - offset
        return sp.expand(sum(
            sp.binomial(kk, u) * sp.binomial(kk, ll - u) * X ** u
            for u in range(max(0, ll - kk), min(kk, ll) + 1)
        ))

    expected_h1 = sp.expand((X - 1) * aux(1))
    expected_h2 = sp.expand((X - 1) ** 2 * aux(2))

    if l <= k:
        max_states = [set(q) for q in itertools.combinations(sorted(A), l)]
    else:
        outside = sorted(set(range(n)) - A)
        max_states = [A | set(q) for q in itertools.combinations(outside, l - k)]
    max_h1 = sp.Rational(sum(h1(q) for q in max_states), len(max_states))
    max_h2 = sp.Rational(sum(h2(q) for q in max_states), len(max_states))
    rr = min(l, n - l)
    expected_max_h1 = sp.Rational(rr, k)
    expected_max_h2 = sp.Rational(rr * (rr - 1), k * (k - 1))

    generator_h1 = True
    generator_h2 = True
    universe = set(range(n))
    for q in states:
        gh1 = 0
        gh2 = 0
        for u in q:
            for v in universe - q:
                q2 = (q - {u}) | {v}
                gh1 += h1(q2) - h1(q)
                gh2 += h2(q2) - h2(q)
        generator_h1 = generator_h1 and (gh1 == -n * h1(q))
        generator_h2 = generator_h2 and (gh2 == -2 * (n - 1) * h2(q))

    return {
        "l": l,
        "kernel_h1_identity": bool(sp.expand(kernel_h1 - expected_h1) == 0),
        "kernel_h2_identity": bool(sp.expand(kernel_h2 - expected_h2) == 0),
        "max_h1_exact": str(max_h1),
        "max_h1_expected": str(expected_max_h1),
        "max_h1_identity": bool(max_h1 == expected_max_h1),
        "max_h2_exact": str(max_h2),
        "max_h2_expected": str(expected_max_h2),
        "max_h2_identity": bool(max_h2 == expected_max_h2),
        "unnormalized_BL_h1_eigen_identity": bool(generator_h1),
        "unnormalized_BL_h2_eigen_identity": bool(generator_h2),
    }

def build_certificates() -> Dict[str, object]:
    out: Dict[str, object] = {
        "description": (
            "For n=2k, the BL surrogate uses degree-two multiplier lambda1^(2(n-1)/n). "
            "The exact channel uses theta2.  The certificate proves lambda1^p-theta2^q>0, "
            "where p/q=2(n-1)/n, on every nontrivial slice for k=3,4."
        ),
        "families": [],
    }
    for k in (3, 4):
        n = 2 * k
        p, q = 2 * k - 1, k
        rows = []
        for l in range(2, k + 1):  # complement symmetry covers n-l
            lam1, theta2 = layer_multipliers(k, l)
            expr = sp.factor(lam1**p - theta2**q)
            cert = positive_for_positive_s(expr)
            rows.append(
                {
                    "l": l,
                    "complement_layer": n - l,
                    "lambda1": str(lam1),
                    "theta2": str(theta2),
                    "power_inequality": f"lambda1^{p} - theta2^{q} > 0",
                    "certificate": cert,
                }
            )
        direct_checks = [direct_enumeration_check(k, l) for l in range(2, n - 1)]
        out["families"].append(
            {
                "n": n,
                "k": k,
                "BL_exponent": f"{p}/{q}",
                "layers": rows,
                "direct_enumeration_checks": direct_checks,
                "all_layer_certificates_pass": all(r["certificate"]["strict_for_s_positive"] for r in rows),
                "all_direct_enumeration_checks_pass": all(
                    all(v is True for key, v in row.items() if key.endswith("identity"))
                    for row in direct_checks
                ),
            }
        )
    return out


def write_text_certificate(data: Dict[str, object], path: Path) -> None:
    lines = [
        "S13 exact positive-polynomial certificate",
        "========================================",
        "",
        data["description"],
        "",
    ]
    for fam in data["families"]:
        lines.append(f"n={fam['n']}, k={fam['k']}, BL exponent={fam['BL_exponent']}")
        for row in fam["layers"]:
            lines.extend(
                [
                    f"  layer l={row['l']} (and l={row['complement_layer']}):",
                    f"    lambda1 = {row['lambda1']}",
                    f"    theta2 = {row['theta2']}",
                    f"    numerator = {row['certificate']['numerator_factorized']}",
                    f"    denominator = {row['certificate']['denominator_factorized']}",
                    f"    strict for s>0 = {row['certificate']['strict_for_s_positive']}",
                ]
            )
        lines.append("")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    certs = build_certificates()
    potential = []
    diagnostics = []
    points = [
        (sp.Rational(19, 20), sp.Rational(1, 100)),
        (sp.Rational(19, 20), sp.Rational(1, 40)),
        (sp.Rational(99, 100), sp.Rational(1, 1000)),
    ]
    for n, k in ((6, 3), (8, 4)):
        pdata = fourier_potential_data(n, k)
        potential.append(pdata)
        delta = mp.mpf(pdata["delta_U_gibbs_minus_uniform_decimal"])
        diagnostics.append(
            {
                "n": n,
                "k": k,
                "points": [aggregate_diagnostic(n, k, c, a, delta) for c, a in points],
            }
        )

    # Verify all Fourier reference partitions, not only the input layer.
    reference_partitions = []
    for n in (6, 8):
        for l in range(n + 1):
            partition = sp.simplify(sum(vandermonde_sq(n, A) for A in all_subsets(n, l)))
            reference_partitions.append(
                {
                    "n": n,
                    "l": l,
                    "partition": str(partition),
                    "expected": str(n**l),
                    "exact": bool(sp.simplify(partition - n**l) == 0),
                }
            )

    result = {
        "schema": "s13-potential-counterexample-v1",
        "exact_polynomial_certificates": certs,
        "fourier_input_potential": potential,
        "reference_partition_checks": reference_partitions,
        "floating_diagnostics": diagnostics,
        "all_exact_checks_pass": bool(
            all(f["all_layer_certificates_pass"] and f["all_direct_enumeration_checks_pass"] for f in certs["families"])
            and all(p["partition_identity_exact"] and p["input_normalization_exact"] and p["nonconstant_witness"]["different_exact"] for p in potential)
            and all(x["exact"] for x in reference_partitions)
        ),
        "versions": {"sympy": sp.__version__, "mpmath": mp.__version__},
    }

    json_path = args.output_dir / "potential_counterexample.json"
    json_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    write_text_certificate(certs, args.output_dir / "potential_polynomial_certificate.txt")
    print(json.dumps({"output": str(json_path), "all_exact_checks_pass": result["all_exact_checks_pass"]}, indent=2))


if __name__ == "__main__":
    main()
