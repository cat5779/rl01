# Checkpoint 01 — exact Fourier reference identity reconstructed

UTC: 2026-09-16T15:38:49.996546+00:00

Verified claim (analytic proof to be written in `proof.md`): for the cyclic Fourier
potential U_n(S)=sum_{i<j in S} log|z_i-z_j|^2 and reference
nu_{n,l}(S)=n^{-l}exp(U_n(S)), Cauchy--Binet gives a normalized law.  For the
actual P_(n,k) channel,

H(Y)=H(M)+E[M]log n-E[U_n(Y)]-sum_l pi_l KL(q_l||nu_{n,l}),

with actual-to-reference KL orientation.  The root discriminant gives
E[U_n(Y)]''=2n log n, hence

H''=H(M)''-2n log n-(sum_l pi_l KL(q_l||nu_{n,l}))''.

The partition contribution E[M]log n has zero second derivative; the claimed
large curvature belongs to the complete reference block, not the partition
term alone.
