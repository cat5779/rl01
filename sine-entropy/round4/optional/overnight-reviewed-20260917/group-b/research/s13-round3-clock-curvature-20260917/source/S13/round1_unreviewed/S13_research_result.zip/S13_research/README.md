# S13 research package

**Status: `DISPROVED_ROUTE_LEMMA`.**

This package reconstructs the exact cyclic Fourier reference identity for the
actual projection-DPP channel and disproves the exact transfer of its aggregate
potential cancellation to the recovered mean-overlap Bernoulli--Laplace
surrogate.

The new theorem is finite but analytic: for genuine `P_(6,3)` and `P_(8,4)`,
for every `0<c<1` and every `0<a<1-c`, the surrogate's actual-count-weighted
Fourier potential is strictly larger than the actual channel's.  Exact
positive-coefficient integer polynomials certify every nontrivial layer.  This
is a route obstruction, not a counterexample to the sine entropy-rate target.

## Main files

- `proof.md` — self-contained definitions, proofs, exact route theorem, and
  evidence classification.
- `RECOVERY_LEDGER.md` — reviewed, reconstructed, refuted, and missing claims.
- `TERM_BALANCE.md` — all normalization, count, layer, acceleration, moving
  weight, and Fisher terms with signs.
- `gap_audit.md` — target-level gaps and limits of the result.
- `attempts.md` — successful and failed proof paths.
- `candidate_ledger.md` — three scouted mechanisms, two promoted.
- `sources.md` — exact packet commit and imported-statement ledger.
- `scripts/potential_counterexample.py` — exact polynomial and partition
  certificates plus decimal diagnostics.
- `scripts/full_atom_checks.py` — exact full-atom and count jets, followed by
  high-precision entropy/Fisher/reference checks.
- `scripts/replay.py` — clean replay and semantic validation.
- `scripts/verify_manifest.py` — SHA-256 manifest verifier.
- `evidence/frozen/` — immutable outputs used by the report.
- `evidence/replay/` — intended location for fresh outputs.
- `evidence/checkpoints/` — concise mathematical recovery checkpoints.

## Reproduce

From the extracted package root:

```bash
python3 scripts/verify_manifest.py SHA256SUMS
python3 scripts/replay.py --output-dir evidence/replay
```

The replay regenerates its files rather than writing into `evidence/frozen`.
It parses JSON semantically, so LF/CRLF differences are not treated as
mathematical failures.

## Evidence levels

- **Analytic:** the Fourier reference identity, exact potential curvature, and
  aggregate route counterexample.
- **Exact finite certificate:** positive polynomial coefficients, reference
  partitions for `n=6,8`, Fourier input normalization, orbit jets, count jets,
  and layer sums.
- **Floating diagnostic:** entropy, KL, Fisher values, and residuals computed at
  110-digit precision from the exact jets.  The theorem does not depend on
  their decimal signs.

## Scope

The package does not prove a growing-density mismatch theorem, a sign for the
mismatch curvature, the recovered entropy/KL approximation claims, a payment
for `W_n`, or the sine entropy-rate target.  A corrected surrogate argument
must retain the additional potential mismatch `C_n` and pay its complete
Jensen defect together with all moving-layer terms.
